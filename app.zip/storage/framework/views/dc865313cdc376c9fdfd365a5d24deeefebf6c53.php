<?php
$settings = \App\Models\AppSettings::first();
?>

<!-- footer Start -->
<footer>
    <div class="footer-top section-pb section-pt-60">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">

                    <div class="widget-footer mt-40">
                        <h6 class="title-widget">Contact Info</h6>

                        <div class="footer-addres">
                            <div class="widget-content mb--20">
                                <p>Address: <?php echo e($settings->address); ?>.</p>
                                <p>Phone: <a href="tel:"><?php echo e($settings->phone); ?></a></p>
                                <p>Whatsapp: <a href="tel:"><?php echo e($settings->whatsapp); ?></a></p>
                                <p>Email: <a href="tel:"><?php echo e($settings->email); ?></a></p>
                            </div>
                        </div>

                        <ul class="social-icons">
                            <li>
                                <a class="facebook social-icon" href="<?php echo e($settings->facebook); ?>" title="Facebook" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>
                            <li>
                                <a class="twitter social-icon" href="<?php echo e($settings->twitter); ?>" title="Twitter" target="_blank"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li>
                                <a class="instagram social-icon" href="<?php echo e($settings->instagram); ?>" title="Instagram" target="_blank"><i class="fa fa-instagram"></i></a>
                            </li>
                           
                        </ul>

                    </div>

                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="widget-footer mt-40">
                        <h6 class="title-widget">Information</h6>
                        <ul class="footer-list">
                            <li><a href="<?php echo e(url("/")); ?>">Home</a></li>
                            <li><a href="<?php echo e(url("/about")); ?>">About Us</a></li>
                            <li><a href="<?php echo e(url("/contact")); ?>">Quick Contact</a></li>
                           
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-md-6 col-sm-6">
                    <div class="widget-footer mt-40">
                        <h6 class="title-widget">Extras</h6>
                        <ul class="footer-list">
                           
                            <li><a href="#">Concord History</a></li>
                            <li><a href="#">Client Feed</a></li>
                            <li><a href="<?php echo e(url("/about")); ?>">About Us</a></li>
                            <li><a href="<?php echo e(url("/contact")); ?>">Quick Contact</a></li>
                           
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="widget-footer mt-40">
                       
                        <ul class="footer-list">
                            <li><img src="<?php echo e(asset('pageassets/images/brand/img-googleplay.jpg')); ?>" alt=""></li>
                            <li><img src="<?php echo e(asset('pageassets/images/brand/img-appstore.jpg')); ?>" alt=""></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6">
                    <div class="copy-left-text">
                        <p>Copyright &copy; <a href="#"><?php echo e(ucwords($settings->name)); ?></a> <?php echo e(date("Y")); ?>. All Right Reserved.</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="copy-right-image">
                        <img src="<?php echo e(asset('pageassets/images/icon/img-payment.png')); ?>" alt="">

                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- footer End -->
  
   
  
   
<!-- Modal -->
<div class="modal fade modal-wrapper" id="exampleModalCenter" >
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-body">
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <div class="modal-inner-area">
                    <div class="row gx-3 product-details-inner">
                        <div class="col-lg-5 col-md-6 col-sm-6">
                            <!-- Product Details Left -->
                            <div class="product-large-slider">
                                <div class="pro-large-img">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-01.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-large-img">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-02.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-large-img ">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-03.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-large-img">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-04.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-large-img">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-05.png')); ?>" alt="product-details" />
                                </div>

                            </div>
                            <div class="product-nav">
                                <div class="pro-nav-thumb">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-01.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-nav-thumb">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-02.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-nav-thumb">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-03.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-nav-thumb">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-04.png')); ?>" alt="product-details" />
                                </div>
                                <div class="pro-nav-thumb">
                                    <img src="<?php echo e(asset('pageassets/images/product/product-05.png')); ?>" alt="product-details" />
                                </div>
                            </div>
                            <!--// Product Details Left -->
                        </div>

                        <div class="col-lg-7 col-md-6 col-sm-6">
                            <div class="product-details-view-content">
                                <div class="product-info">
                                    <h3>Single product One</h3>
                                    <div class="product-rating d-flex">
                                        <ul class="d-flex">
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                            <li><a href="#"><i class="icon-star"></i></a></li>
                                        </ul>
                                        <a href="#reviews">(<span class="count">1</span> customer review)</a>
                                    </div>
                                    <div class="price-box">
                                        <span class="new-price">$70.00</span>
                                        <span class="old-price">$78.00</span>
                                    </div>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam fringilla augue nec est tristique auctor.</p>

                                    <div class="single-add-to-cart">
                                        <form action="#" class="cart-quantity d-flex">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input type="number" class="input-text" name="quantity" value="1" title="Qty">
                                                </div>
                                            </div>
                                            <button class="add-to-cart" type="submit">Add To Cart</button>
                                        </form>
                                    </div>
                                    <ul class="single-add-actions">
                                        <li class="add-to-wishlist">
                                            <a href="wishlist.html" class="add_to_wishlist"><i class="icon-heart"></i> Add to Wishlist</a>
                                        </li>
                                    </ul>
                                    <ul class="stock-cont">
                                        <li class="product-stock-status">Categories: <a href="#">Watchs,</a> <a href="#">Man Watch</a></li>
                                        <li class="product-stock-status">Tag: <a href="#">Man</a></li>
                                    </ul>
                                    <div class="share-product-socail-area">
                                        <p>Share this product</p>
                                        <ul class="single-product-share">
                                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            </div>
        </div>
    </div>   
</div>

</div>

<!-- JS
============================================ -->

<!-- Modernizer JS -->
<script src="<?php echo e(asset('pageassets/js/vendor/modernizr-3.6.0.min.js')); ?>"></script>

<!-- jquery -->		
<script src="<?php echo e(asset('pageassets/js/vendor/jquery-3.6.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/vendor/jquery-migrate-3.4.0.min.js')); ?>"></script>		

<!-- Bootstrap JS -->
<script src="<?php echo e(asset('pageassets/js/vendor/bootstrap.min.js')); ?>"></script>

<!-- Plugins JS -->
<script src="<?php echo e(asset('pageassets/js/plugins/slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/countdown.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/image-zoom.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/fancybox.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/scrollup.min.js')); ?>"></script>
<script src="<?php echo e(asset('pageassets/js/plugins/jqueryui.min.js')); ?>"></script> 
<script src="<?php echo e(asset('pageassets/js/plugins/ajax-contact.js')); ?>"></script>

<script src="<?php echo e(asset('pageassets/js/main.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/layouts/page_footer.blade.php ENDPATH**/ ?>