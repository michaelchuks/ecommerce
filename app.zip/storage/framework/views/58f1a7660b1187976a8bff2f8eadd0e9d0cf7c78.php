
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
<h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span><?php echo e(ucwords($product->name)); ?> Images
    </span> <a href="<?php echo e(url("admin/newimage/$product->id")); ?>" class="btn btn-sm btn-success">Add More Images</a> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->
                <?php if(count($images) != 0): ?>
                <div class="table-responsive">
                    <table class="table">
                     <thead>
                        <tr><th></th><th></th></tr>
                        <thead>
                            <tbody>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr><td><img src="<?php echo e(asset("storage/productimages/$image->image")); ?>" style="height:150px;width:100px" /></td>
                                    <td><form method="post" action="<?php echo e(route('product.deleteimage')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>" />
                                        <input type="submit" name="delete_image_btn" onclick="confirm('are you sure you want to delete image')" value="Delete" class="btn btn-sm btn-danger" />
                                        </form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                    </table>

                </div>
                <?php else: ?> 
                 <strong class="text-danger">No Extra images added
                <?php endif; ?>
                <br />
                <br />
                <a href="<?php echo e(url("admin/products")); ?>" class="btn btn-sm btn-danger">Back to products</a>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/images.blade.php ENDPATH**/ ?>