
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Product List
    </span> 
    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-sm btn-success">Add Product</a> 
    <input type="text" name="product" placeholder="Search Product by name" id="product" onkeyup="searchProduct()" />
</h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>

                <!--content-->
               <?php endif; ?>

               <?php if(Session::get("error")): ?>
               <div class="alert alert-danger">
                <strong class="text-danger"><?php echo e(Session::get("danger")); ?></strong>
               </div>

               <!--content-->
              <?php endif; ?>
               <?php if(count($products) == 0): ?>
               <strong class="text-danger">No Products added yet</strong>
           
               <?php else: ?>

           <div class="table-responsive" id="deposits-content">
           <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <p><small><strong>Note : Promoted products are products that appears on the face page of the website</strong></small></p>
           <thead>
               <tr><th>Name</th><th>Image</th><th>Price</th><th>Quantity Available</th><th>Status</th><th>Promotion</th><th></th><th></th><th></th><th></th></tr>
           </thead>
           <tbody id="tbody">
             <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr><td><?php echo e(ucwords($product->name)); ?></td>
               <td><img src="<?php echo e(asset("storage/productimages/$product->image")); ?>" style="height:100px;width:120px"/></td>
               <td>N<?php echo e($product->price); ?></td><td><?php echo e($product->quantity); ?></td>
               <td>
                <?php if($product->status == "available"): ?>
                <strong class="text-success">Available</strong>
                <?php else: ?>
                <strong class="text-danger">Out Of Stock</strong>
                <?php endif; ?>
               </td>
               <td>
                <?php if($product->is_promoted == true): ?>
                <strong>Promoted</strong>
                <?php else: ?>
                <strong>Not Promoted</strong>
                <?php endif; ?>
               </td>
               <td>
                <?php if($product->is_promoted == false): ?>
                <a href="<?php echo e(url("admin/promoteproduct/$product->id")); ?>" class="btn btn-sm btn-info">Promote Product</a>
                <?php else: ?>
                <a href="<?php echo e(url("admin/promoteproduct/$product->id")); ?>" class="btn btn-sm btn-warning">Disable Promotion</a>
                <?php endif; ?>
               </td>
               <td><a href="<?php echo e(url("admin/product/$product->id")); ?>" class="btn btn-sm btn-primary">View</a></td> 
               <td><a href="<?php echo e(url("admin/editproduct/$product->id")); ?>" class="btn btn-sm btn-success">Edit</a></td> 
               <td>
                <form method="post" action="<?php echo e(url("product.delete")); ?>">
                    <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                <input type="submit" name="delete_product_btn" class="btn btn-sm btn-danger" value="Delete" onclick="confirm('are you sure you want to delete this product')" />
                </td> 
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </tbody>
           </table>
           <br />
   
        
           </div>
           <br />
           <?php echo e($products->links()); ?>

           <?php endif; ?>

           <!--end of content-->
   
       </div>
      </div>

      <script>
        function searchProduct(){
            var product = document.getElementById("product");
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function(){
                if(this.readyState == 4 && this.status == 200){
                    document.getElementById('tbody').innerHTML = this.responseText;
                }
            }

            xhttp.open("GET","searchproduct?product="+product,true);
            xhttp.send();
        }
        </script>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/index.blade.php ENDPATH**/ ?>