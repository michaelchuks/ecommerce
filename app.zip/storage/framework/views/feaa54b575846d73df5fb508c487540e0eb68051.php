
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span><?php echo e(ucwords($product->name)); ?>

    </span> <a href="<?php echo e(url("admin/editproduct/$product->id")); ?>" class="btn btn-sm btn-success">Edit</a> 
    <a href="<?php echo e(url("admin/productimages/$product->id")); ?>" class="btn btn-sm btn-primary">View Images</a>
</h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->
                 <div class="row">
                <div class='col-md-6'>
                <p>Name : <?php echo e(ucwords($product->name)); ?></p>
                <p>Product Category: <?php echo e(ucwords($product->category)); ?></p>
                <p><img src="<?php echo e(asset("storage/productimages/$product->image")); ?>" style="height:200px;width:200px;" />
                <?php if($product->color != "" || $product->color != null): ?>
                <p>Colors Available : <?php echo e(ucwords($product->color)); ?>

                <?php endif; ?>
                <?php if($product->size != "" || $product->size != null): ?>
                <p>Sizes Available : <?php echo e($product->size); ?>

                <?php endif; ?>
                </div>

                <div class='col-md-6'>
                    <?php if($product->video != null || $product->video != ""): ?>
                    <video width="320" height="240" controls>
                        <source src="<?php echo e(asset("storage/productvideos/$product->video")); ?>" type="video/mp4">
                      
                        Your browser does not support the video tag.
                      </video>
                       <?php endif; ?>
                      <p>Quantity Available : <?php echo e($product->quantity); ?> psc</p>
                      <p>Price : <strong>N<?php echo e($product->price); ?></strong></p>
                      <?php if($product->discount != 0 || $product->discount != ""): ?>
                      <P>Discount <?php echo e($product->discount); ?>%</P>
                      <?php endif; ?>
                       <?php if($product->is_promoted == true): ?>
                       <p>is promoted : true</p>
                       <?php else: ?>
                       <p>is promoted : false</p>
                      <?php endif; ?>
                 
                </div>

                <p>Product Description</p>
                <p><?php echo e(ucwords($product->description)); ?></p>

                </div>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/show.blade.php ENDPATH**/ ?>