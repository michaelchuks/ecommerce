
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Home Page Content
    </span> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->

                <div class="table-responsive">
                    <table class="table">
                        <thead><tr><th></th><th></th><th></th></thead>
                            <tbody>
                    <tr><td>Slider 1</td>
                        <td>
                        <?php if($content != null && $content->slider1 != null): ?>
                        <img src="<?php echo e(asset("storage/content/$content->slider1")); ?>" style="height:200px;width:200px;" />
                        <?php endif; ?>
                        </td>

                        <td>
                            <form method="post" action="<?php echo e(url("admin/updateheroimage")); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                            <input type="file" name="slider1" class="form-control" required />
                         
                            <br />

                            <input type="submit" name="update_slider_image_btn" class="btn btn-sm btn-primary" value="Update" />
                            </form>
                        </td>
                    
                    </tr>


                    <tr><td>Slider 2</td>
                        <td>
                        <?php if($content != null && $content->slider2 != null): ?>
                        <img src="<?php echo e(asset("storage/content/$content->slider2")); ?>" style="height:200px;width:200px;" />
                        <?php endif; ?>
                        </td>

                        <td>
                            <form method="post" action="<?php echo e(url("admin/updateheroimage")); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                            <input type="file" name="slider2" class="form-control" required />
                           
                            <br />

                            <input type="submit" name="update_slider_image_btn" class="btn btn-sm btn-primary" value="Update" />
                            </form>
                        </td>
                    
                    </tr>



                    <tr><td>Slider 3</td>
                        <td>
                        <?php if($content != null && $content->slider3 != null): ?>
                        <img src="<?php echo e(asset("storage/content/$content->slider3")); ?>" style="height:200px;width:200px;" />
                        <?php endif; ?>
                        </td>

                        <td>
                            <form method="post" action="<?php echo e(url("admin/updateheroimage")); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                            <input type="file" name="slider3" class="form-control" required />
                         
                            <br />

                            <input type="submit" name="update_slider_image_btn" class="btn btn-sm btn-primary" value="Update" />
                            </form>
                        </td>
                    
                    </tr>


                    <tr><td>Slider 4</td>
                        <td>
                        <?php if($content != null && $content->slider4 != null): ?>
                        <img src="<?php echo e(asset("storage/content/$content->slider4")); ?>" style="height:200px;width:200px;" />
                        <?php endif; ?>
                        </td>

                        <td>
                            <form method="post" action="<?php echo e(url("admin/updateheroimage")); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                            <input type="file" name="slider4" class="form-control" required />
                          
                            <br />

                            <input type="submit" name="update_slider_image_btn" class="btn btn-sm btn-primary" value="Update" />
                            </form>
                        </td>
                    
                    </tr>

                    <tr>
                    <td>Hero Heading</td>
                    <td>
                        <?php if($content != null && $content->hero_heading != null): ?>
                        <?php echo e($content->hero_heading); ?>

                        <?php endif; ?>
                    </td>
                    <td><form method="post" action="<?php echo e(url("admin/updatecontent")); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="text" <?php if($content != null && $content->hero_heading != null): ?>value="<?php echo e($content->hero_heading); ?>"<?php endif; ?> name="hero_heading" class="form-control" />
                         <br />
                        <input type="submit" name="update_content_btn" value="Update" class="btn btn-sm btn-primary" />
                    </form>
                    </tr>


                    <td>Hero Top</td>
                    <td>
                        <?php if($content != null && $content->hero_top != null): ?>
                        <?php echo e($content->hero_top); ?>

                        <?php endif; ?>
                    </td>
                    <td><form method="post" action="<?php echo e(url("admin/updatecontent")); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="text" <?php if($content != null && $content->hero_top != null): ?>value="<?php echo e($content->hero_top); ?>"<?php endif; ?> name="hero_top" class="form-control" />
                        <br />
                        <input type="submit" name="update_content_btn" value="Update" class="btn btn-sm btn-primary" />
                    </form>
                    </tr>



                    <td>Hero Subtext</td>
                    <td>
                        <?php if($content != null && $content->hero_subtext != null): ?>
                        <?php echo e($content->hero_subtext); ?>

                        <?php endif; ?>
                    </td>
                    <td><form method="post" action="<?php echo e(url("admin/updatecontent")); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="text" <?php if($content != null && $content->hero_subtext != null): ?>value="<?php echo e($content->hero_subtext); ?>"<?php endif; ?> name="hero_subtext" class="form-control" />
                         <br />
                        <input type="submit" name="update_content_btn" value="Update" class="btn btn-sm btn-primary" />
                        </form>
                    </tr>

                            </tbody>

                    </table>

                </div>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/settings/homepage_content.blade.php ENDPATH**/ ?>