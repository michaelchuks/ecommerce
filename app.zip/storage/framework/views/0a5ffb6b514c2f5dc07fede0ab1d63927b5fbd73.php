
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Add <?php echo e(ucwords($product->name)); ?> image
    </span> <a href="<?php echo e(url("admin/productimages/$product->id")); ?>" class="btn btn-sm btn-success">back to Imgaes</a> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->
                <form method="post" action="<?php echo e(route('product.savenewimage')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <label>Select Image</label>
                    <input type="file" name="image" class="form-control" required />
                    <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                    <br />

                    <input type="submit" name="save_image_btn" class="btn btn-sm btn-primary" value="Save Image" />

                </form>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/newimage.blade.php ENDPATH**/ ?>