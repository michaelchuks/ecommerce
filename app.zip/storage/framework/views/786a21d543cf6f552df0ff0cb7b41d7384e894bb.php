
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Best Seller Product
    </span></h6>
   </div>
   
   <?php
    $promoted_product = \App\Models\Products::find($best_seller->promoted_product_id);
   ?>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->
                <p><small><strong>Best seller product is the product that appears on the best seller section of the homepage</strong></small></p>
                <form method="post" action="<?php echo e(url("admin/updatebestseller")); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <label>Select Best Seller Product</label>
                <select name="product_id" class="form-control">
                <option value="<?php echo e($best_seller->promoted_product_id); ?>"><?php echo e(ucwords($promoted_product->name)); ?></option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->id != $best_seller->promoted_product_id): ?>
                <option value="<?php echo e($product->id); ?>"><?php echo e(ucwords($product->name)); ?></option>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <br />

                <label>Best Seller Image</label>
                <?php if($best_seller->promotion_image != null): ?>
                <p><img src="<?php echo e(asset("storage/promotion/$best_seller->promotion_image")); ?>" style="width:400px;height:300px;" /></p>
                <?php endif; ?>
                <input type="file" name="promotion_image" class='form-control' />

                <br />

                <label>Best Seller Heading</label>
                <input type="text" name="promotion_heading" class="form-control" value="<?php echo e($best_seller->promotion_heading); ?>" />

                <br />
                <label>Best Seller Content</label>
                <textarea class='form-control' name="promotion_content"><?php echo e($best_seller->promotion_content); ?></textarea>
                <br />

                <input type="submit" name="update_best_seller" class="btn btn-sm btn-primary" value="Update" />
                </form>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/settings/best_seller.blade.php ENDPATH**/ ?>