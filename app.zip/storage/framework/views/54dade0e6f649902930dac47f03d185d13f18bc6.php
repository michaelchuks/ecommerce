
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Account Settings
    </span>  </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->

                <form method="post" action="<?php echo e(url("admin/updateaccount")); ?>">
                    <?php echo csrf_field(); ?>
                <label>Email</label>
                <input type="email" name="email" class='form-control' value="<?php echo e($account->email); ?>" />
                <br />

                <label>New Password</label>
                <input type="text" name="password" class="form-control" />
                <br />

                <input type="submit" name="update_account_btn" value="Update Account" class="btn btn-sm btn-primary" />

                </form>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/settings/account.blade.php ENDPATH**/ ?>