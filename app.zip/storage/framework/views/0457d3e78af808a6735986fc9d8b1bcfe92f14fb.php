
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Dropifypay Subadmins
    </span> <?php if(count($subscribers) != 0): ?><a href="<?php echo e(route('admin.sendemail')); ?>" class="btn btn-sm btn-success">Broadcast Email</a><?php endif; ?></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->

                <?php if(count($subscribers) == 0): ?>
                <strong class="text-danger">No subscribers yet</strong>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead><th>Email</th><th></th></thead>
                        <tbody>
                            <?php $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr><td><?php echo e($user->email); ?></td><td><a href="<?php echo e(url("admin/deletesubscriber/$user->id")); ?>" class="btn btn-sm btn-danger">Delete</a></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <?php endif; ?>

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/customers/subscribers.blade.php ENDPATH**/ ?>