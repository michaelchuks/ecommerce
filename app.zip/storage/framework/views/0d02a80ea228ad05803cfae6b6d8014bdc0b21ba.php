<!-- news letter starts-->
<div class="newletter-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="newletter-wrap">
                    <div class="row align-items-center">
                        <div class="col-lg-7 col-md-12">
                            <div class="newsletter-title mb-30">
                                <h3>Join Our <br><span>Newsletter Now</span></h3>
                            </div>
                        </div>

                        <div class="col-lg-5 col-md-7">
                            <div class="newsletter-footer mb-30">
                                <form method="post" action="<?php echo e(url("/subscribe")); ?>">
                                    <?php echo csrf_field(); ?>
                                <input type="text" placeholder="Your email address...">
                                <div class="subscribe-button">
                                    <button class="subscribe-btn" type="submit">Subscribe</button>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- news letter endsd--><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/layouts/news_letter.blade.php ENDPATH**/ ?>