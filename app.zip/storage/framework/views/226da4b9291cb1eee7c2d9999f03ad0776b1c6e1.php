
<?php $__env->startSection("content"); ?>


        <!-- breadcrumb-area start -->
        <div class="breadcrumb-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <!-- breadcrumb-list start -->
                        <ul class="breadcrumb-list">
                            <li class="breadcrumb-item"><a href="<?php echo e(url("/")); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Contact <?php echo e(ucwords($settings->name)); ?></li>
                        </ul>
                        <!-- breadcrumb-list end -->
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb-area end -->

        <!-- Page Conttent -->
        <main class="page-content section-ptb">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-sm-12">
                        <div class="contact-form">
                            <div class="contact-form-info">
                                <div class="contact-title">
                                    <h3>Reach Out</h3>
                                    <?php if(Session::get('success')): ?>
                                    <div class="alert alert-success">
                                        <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <form  action="<?php echo e(url("/processcontact")); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="contact-page-form">
                                        <div class="contact-input">
                                            <div class="contact-inner">
                                                <input name="name" type="text" placeholder="Name *" required
                                                >
                                            </div>
                                            <div class="contact-inner">
                                                <input name="email" type="email" placeholder="Email *" required>
                                            </div>
                                            <div class="contact-inner">
                                                <input name="phone" type="text" placeholder="Phone *" required>
                                            </div>
                                            <div class="contact-inner">
                                                <input name="subject" type="text" placeholder="Subject *" required>
                                            </div>
                                            <div class="contact-inner contact-message">
                                                <textarea name="message" placeholder="Message *" required></textarea>
                                            </div>
                                        </div>
                                        <div class="contact-submit-btn">
                                            <button class="submit-btn" type="submit">Send Email</button>
                                            <p class="form-messege"></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-sm-12">
                        <div class="contact-infor">
                            <div class="contact-title">
                                <h3>CONTACT US</h3>
                            </div>
                            <div class="contact-dec">
                                <p>Reach out to us</p>
                            </div>
                            <div class="contact-address">
                                <ul>
                                    <li>Address : <?php echo e($settings->address); ?></li>
                                    <li>Email: <?php echo e($settings->email); ?>/li>
                                    <li>Phone: <?php echo e($settings->phone); ?></li>
                                    <li>WhatsApp : <a href="https://wa.me/<?php echo e($settings->whatsapp); ?>" style="color:green;">Chat on whatsapp</a></li>
                                </ul>
                            </div>
                            <div class="work-hours">
                                <h5>Working hours</h5>
                                <p><strong>Monday &ndash; Sunday</strong></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--// Page Conttent -->

<?php echo $__env->make("layouts.page_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.page_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/contact.blade.php ENDPATH**/ ?>