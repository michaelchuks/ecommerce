
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Update <?php echo e(ucwords($product->name)); ?>

    </span> <a href="<?php echo e(route('product.index')); ?>" class="btn btn-sm btn-success">Products</a> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>

                <!--content-->

                <form method="post" action="<?php echo e(route('product.update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <label>Product Name</label>
                        <input type="text" name="name" class='form-control' value="<?php echo e(ucwords($product->name)); ?>" />
                        <br />
                        <label>Product Image</label>
                        <input type="file" name="image" accept="image/*" class="form-control" />
                        <br />

                        <label>Colors Available(optional)</label>
                        <input type="text" name='colors' <?php if($product->color != "" || $product->color != null): ?>value="<?php echo e($product->color); ?>"<?php endif; ?> class="form-control"/>
                        <br />

                        <label>Product Price(N)</label>
                        <input type="number" name="price" class="form-control" value="<?php echo e($product->price); ?>" />
                        <br />

                        <label>Product Description</label>
                        <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>

                       
                    </div>

                    <div class='col-md-6'>
                        <label>Select Category</label>
                        <select name="category" class='form-control'>
                            <option value="<?php echo e($product->category); ?>"><?php echo e(ucwords($product->category)); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($category->category != $product->category): ?>
                            <option value="<?php echo e($category->category); ?>"><?php echo e(ucwords($category->category)); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                         <br />
                        <label>Product Video(optional)</label>
                        <input type="file" name="video" class='form-control' accept=".mp4, .avi"  />

                        <br />
                        <label>Sizes Available(optional)</label>
                        <input type="text" name='sizes' <?php if($product->size != null || $product->size != ""): ?>value="<?php echo e($product->size); ?>"<?php endif; ?> class="form-control"/>
                        <br />

                        <label>Discount(%) if any</label>
                        <input type="number" name="discount" <?php if($product->discount != 0 || $product->discount != ""): ?>value="<?php echo e($product->discount); ?>"<?php endif; ?> step='any' class="form-control" />
                        <br />
                        <label>Quantity Available</label>
                        <input type="number" name="quantity" class="form-control" value="<?php echo e($product->quantity); ?>"/>
                        <br />
                        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                        <input type="submit" name="update_product_btn" value="Update Product" class="btn btn-sm btn-primary" />
                    </div>
                </div>
                

                </form>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/edit.blade.php ENDPATH**/ ?>