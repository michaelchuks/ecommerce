
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
            class="fas fa-download fa-sm text-white-50"></i> Records</a>
</div>

<!-- Content Row -->
<div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Products</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($total_products); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div>
                           Total Orders</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($total_orders); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-book fa-2x text-danger"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>


     <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                          Total Reviews</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($total_reviews); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                           Pending Orders</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($pending_orders); ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-money fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

  

</div>           

     

<div class="row">
<div class="col-md-12">

<div class="card">
    <div class="card-header">
        <h5>Recent Orders</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr><th>Name</th><th>Email</th><th>Phone</th><th>Product Ordered</th><th>Quantity</th><th>Total Amount</th><th>Status</th><th></th><th></th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $recent_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr><td><?php echo e($order->name); ?></td>
                    <td><?php echo e($order->email); ?></td>
                    <td><?php echo e($order->phone); ?></td>
                    <td><?php echo e(ucwords($order->product->name)); ?></td>
                    <td><?php echo e($order->Quantity); ?></td>
                    <td>N<?php echo e($order->total_amount); ?></td>
                    <td>
                      <?php if($order->status == "pending"): ?><strong class="text-danger">Pending</strong>
                      <?php else: ?>
                      <strong class="text-success">Delievered</strong>
                      <?php endif; ?>
                    </td>

                    <td><a href="<?php echo e(url(admin/order/$order->id)); ?>" class="btn btn-sm btn-success">View</a></td>
                    <td>
                        <form method="post" action="<?php echo e(url("admin/deleteorder")); ?>">
                            <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>" />

                        <input type="submit" name="delete_order_btn" value="Delete" onclick="confirm('are you sure you want to delete this order')" />
                        </form>
                    </td>
                
                </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
   

</div>
</div>




<?php echo $__env->make('layouts.admin_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>