
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span>Pending Orders
    </span></h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->
                <?php if(count($orders) == 0): ?>
               <strong class="text-danger">No completed orders record yet</strong>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr><th>Name</th><th>Product</th><th>Quantity</th><th>Price/Product</th><th>Total Amaount</th><th>Phone</th><th></th><th></th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr><td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->product->name); ?></td>
                        <td><?php echo e($product->quantity); ?></td>
                        <td>&#8358;<?php echo e($order->amount); ?></td>
                        <td>&#8358;<?php echo e($order->total_amount); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><a href="<?php echo e(url("admin/confirmorder/$order->id")); ?>" class="btn btn-sm btn btn-primary">Confirm </a></td>


                        <td><a href="<?php echo e(url("admin/order/$order->id")); ?>" class="btn btn-sm btn-success">View</td>
                            <td><form method="post" action="<?php echo e(url("admin/deleteorder")); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>" />

                                <input  onclick="confirm('are you sure you want to delete this order')" type="submit" name="delete_order_btn" value="Delete" class="btn btn-sm btn-danger">

                                </form></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <br />
                <?php echo e($orders->links()); ?>

                <?php endif; ?>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/orders/pending_orders.blade.php ENDPATH**/ ?>