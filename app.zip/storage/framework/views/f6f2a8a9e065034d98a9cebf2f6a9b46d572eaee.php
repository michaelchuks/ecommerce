
<?php $__env->startSection("content"); ?>
<?php echo $__env->make("layouts.admin_navigation", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
   <h6 class="m-0 font-weight-bold text-success" style="display:flex;align-items:center;justify-content:space-between;"><span><?php echo e(ucwords($settings->name)); ?> settings
    </span> </h6>
   </div>
       
       <div class="card-body">
           <div class="card-body">
               <?php if(Session::get("success")): ?>
                <div class="alert alert-success">
                 <strong class="text-success"><?php echo e(Session::get("success")); ?></strong>
                </div>
                <?php endif; ?>
                <!--content-->

                <form method="post" action="<?php echo e(route('admin.updatesettings')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                <div class="row">
                <div class="col-md-6">
                    <label>Site Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($settings->name); ?>" required/>
                    <br />
                    <label>Phone No</label>
                    <input type="tel" name="phone" class="form-control" value="<?php echo e($settings->phone); ?>" required/>
                    <br />

                    <label>Whatsapp No</label>
                    <input type="tel" name="whatsapp" class="form-control" value="<?php echo e($settings->whatsapp); ?>" required/>

                    <br />

                    <label>Instagram page(optional)</label>
                    <input type="text" name="instagram" class="form-control" value="<?php echo e($settings->instagram); ?>"/>
                    <br />

                    <?php if($settings->logo != null || $settings->logo != ""): ?>
                    <img src="<?php echo e(asset("storage/logo/$settings->logo")); ?>" style="width:50px;height:50px;" />
                    <br />
                    <?php endif; ?>
                    <input type="file" name="logo" class="form-control" />
                </div>

                <div class="col-md-6">
                    <label>Site Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e($settings->email); ?>" required/>
                    <br />
                    <label>Address</label>
                    <input type="text" name="address" class="form-control" value="<?php echo e($settings->address); ?>" required/>
                    <br />

                    <label>Facebook page(optional)</label>
                    <input type="text" name="facebook" class="form-control" value="<?php echo e($settings->facebook); ?>"/>
                    <br />

                    <label>Twitter (optional)</label>
                    <input type="text" name="twitter" class="form-control" value="<?php echo e($settings->twitter); ?>"/>

                    <br />
                    <input type="hidden" name="settings_id" value="<?php echo e($settings->id); ?>" />
                    <input type="submit" name="update_settings_btn" value="Update" class="btn btn-sm btn-primary" />
                </div>

                </div>

                </form>
             

           <!--end of content-->
   
       </div>
      </div>


 <?php echo $__env->make("layouts.admin_footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.admin_header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/settings/settings.blade.php ENDPATH**/ ?>