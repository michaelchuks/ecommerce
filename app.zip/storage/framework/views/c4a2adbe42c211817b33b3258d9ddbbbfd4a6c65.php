<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e(ucwords($product->name)); ?></td>
    <td><img src="<?php echo e(asset("storage/productimages/$product->image")); ?>" style="height:100px;width:120px"/></td>
    <td>N<?php echo e($product->price); ?></td><td><?php echo e($product->quantity); ?></td>
    <td>
    </td>
    <td><a href="<?php echo e(url("admin/product/$product->id")); ?>" class="btn btn-sm btn-primary">View</a></td> 
    <td><a href="<?php echo e(url("admin/editproduct/$product->id")); ?>" class="btn btn-sm btn-success">Edit</a></td> 
    <td>
     <form method="post" action="<?php echo e(url("product.delete")); ?>">
         <?php echo csrf_field(); ?>
     <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
     <input type="submit" name="delete_product_btn" class="btn btn-sm btn-danger" value="Delete" onclick="confirm('are you sure you want to delete this product')" />
     </td> 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/admin/dashboard/product/search.blade.php ENDPATH**/ ?>